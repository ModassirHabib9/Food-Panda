class SliderModel {
  String? image;
  SliderModel({
    this.image,
  });
}
