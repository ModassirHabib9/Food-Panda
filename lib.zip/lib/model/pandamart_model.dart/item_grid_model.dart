class ItemGrid {
  String? image;
  String? tilte;
  int? items;
  ItemGrid({
    this.image,
    this.tilte,
    this.items,
  });
}
