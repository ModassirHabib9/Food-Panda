class Sucie {
  String? name;
  String? img;
  num? price;
  Sucie({
    this.name,
    this.img,
    this.price,
  });
}
