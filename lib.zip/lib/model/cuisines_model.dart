class CuisinesModel {
  final String? imgc;
  final String? title;

  CuisinesModel({
    this.imgc,
    this.title,
  });
}
