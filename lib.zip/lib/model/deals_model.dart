class DealsModel {
  final String? img;

  DealsModel({
    this.img,
  });
}
